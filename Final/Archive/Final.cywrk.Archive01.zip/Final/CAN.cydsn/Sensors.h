#pragma once

#include <stdio.h>

int32_t getTemp();
int32_t getHum();
